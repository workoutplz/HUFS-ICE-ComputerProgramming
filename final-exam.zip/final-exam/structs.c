//
//  structs.c
//  finalexam
//
//  Created by wonjunlee on 2020/06/23.
//  Copyright © 2020 wonjun. All rights reserved.
//

#include "structs.h"

int bIdx=0;
int aIdx=0;
